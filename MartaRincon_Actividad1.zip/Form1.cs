using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace Kamil
{
    public partial class Form1 : Form
    {
        private const string V = "Data Source=LAPTOP-RL7L00M9\\SQLEXPRESS;Initial Catalog=Kamil;Integrated Security=True";

        //Cadena de Conexion
        string cadena = V;
        public SqlConnection Conectarbd = new SqlConnection();
        public Form1()
        {
            InitializeComponent();
            Conectarbd.ConnectionString = cadena;
            abrir();
            
        }
        //Metodo para abrir la conexion
        public void abrir()
        {
            try
            {
                Conectarbd.Open();
                MessageBox.Show("Conexi�n abierta");
            }
            catch (Exception ex)
            {
                Console.WriteLine("error al abrir BD " + ex.Message);
            }
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnEmpleados_Click(object sender, EventArgs e)
        {
            FormEmpleados formEmpleados = new FormEmpleados();
            formEmpleados.Show();
        }

        private void btnDirectivos_Click(object sender, EventArgs e)
        {
       
            FormDirectivos formdirectivos = new FormDirectivos();
            formdirectivos.Show();       }

        private void btnCentros_Click(object sender, EventArgs e)
        {
            FromCentros fromCentros = new FromCentros();

            fromCentros.Show();

        }

        private void btnPuestos_Click(object sender, EventArgs e)
        {
            FormPuestoa formPuestoa = new FormPuestoa();
            formPuestoa.Show();
        }
    }
}